Style Guide
HTML/CSS: https://google.github.io/styleguide/htmlcssguide
Javascript: https://google.github.io/styleguide/javascriptguide.xml

NB: comprimere Javascript, CSS e HTML prima di usare questo progetto in produzione.
